import datetime
import redis
import json
import numpy as np
import base64
import os
import cv2


"""
경로 확인 필요합니다
"""

src = "../data/target/faces-17"  # 증명 사진(머그샷)을 읽어들일 경로입니다. 하위 디렉토리 구조는 딥러닝 프로세스 참고바랍니다.
dt = datetime.datetime.now().strftime("%Y%m%d%H%M%S")  # 탐지된 얼굴 파일을 저장할 디렉토리명으로 실행시작시각을 사용합니다.
dst = "../data/output/faces-17/" + dt  # 탐지된 얼굴 파일을 저장하는 경로입니다.

os.makedirs(dst, exist_ok=True)
stream = None
rData_simple = {}  # 사진과 간단한 정보를 출력하기 위해 정보를 수집하는 딕셔너리 입니다.
rData_detail = {}  # 식별된 인물의 자세한 정보를 출력하기 위해 정보를 수집하는 딕셔너리 입니다.
rd = redis.StrictRedis(host='localhost', port=6379, db=0)  # 딥러닝 프로세스와 포트 번호 일치시켜야 합니다
rd.flushall()  # in-memory DB를 초기화합니다.
fidx = 0


def redis_get_data_simple():
    global rd
    global rData_simple
    global fidx

    nData = rd.get("dict_simple")  # redis에서 데이터를 꺼냅니다.
    if nData:
        nData = nData.decode('utf-8')
        if nData:
            tmp_rData = json.loads(nData)  # 변환과정에 사용하는 변수
            if len(tmp_rData.keys()) != len(rData_simple.keys()):  # 변화가 있는지 확인합니다.
                rData_simple.update({k: tmp_rData[k] for k in set(tmp_rData.keys()) - set(rData_simple.keys())})  # 새로운 정보만 추립니다.
            last_key = str(max([int(k) for k in rData_simple.keys()]))

            # 버퍼 이미지를 받아 디코딩합니다.
            if rd.llen("det" + rData_simple[last_key]["ID"]) > 0:
                tmb = rd.rpop("det" + rData_simple[last_key]["ID"])
                tmb = json.loads(tmb)
                img = np.frombuffer(base64.b64decode(tmb), dtype=np.uint8)
                img = cv2.imdecode(img, flags=1)

                save_path = os.path.join(dst, rData_simple[last_key]["INDEX"] + rData_simple[last_key]["ID"] + ".jpg")

                # 재차 저장하지 않도록 이미 이미지가 존재하는지 확인합니다.
                if not os.path.isfile(save_path):
                    cv2.imwrite(save_path, img)

                # 각 얼굴 이미지 파일의 주소를 딕셔너리에 저장합니다.
                rData_simple[last_key].update({"DETECTED": "<img src=\"/images_det/" + dt + "/" + rData_simple[last_key]["INDEX"] + rData_simple[last_key]["ID"] + ".jpg\" width=100 height=100>"})
                rData_simple[last_key].update({"ID_PHOTO": "<img src=\"/images_gt/" + rData_simple[last_key]["NAME"] + "/" + rData_simple[last_key]["NAME"] + ".jpg\" width=100 height=100>"})
    return rData_simple


def redis_get_data_detail():
    global rd
    global rData_detail
    global fidx

    nData = rd.get("dict_detail")  # redis에서 데이터를 꺼냅니다.
    if nData:
        nData = nData.decode('utf-8')
        if nData:
            tmp_rData = json.loads(nData)  # 변환과정에 사용하는 변수
            if len(tmp_rData.keys()) != len(rData_detail.keys()):  # 변화가 있는지 확인합니다.
                rData_detail.update({k: tmp_rData[k] for k in set(tmp_rData.keys()) - set(rData_detail.keys())})  # 새로운 정보만 추립니다.
    return rData_detail


def get_video():
    global rd
    stream = rd.get("vid")
    stream = stream.decode('utf-8')
    stream = json.loads(stream)

    return stream


def get_buf_video():
    global rd
    global stream
    if rd.llen("vid") > 0:
        stream = rd.rpop("vid")
        stream = json.loads(stream)
    return stream
