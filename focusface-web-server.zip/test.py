from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import datetime
import redis_usr

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.get("/index", response_class=HTMLResponse)
async def read_item(request: Request):
    return templates.TemplateResponse("rtcds.html", {"request": request})


@app.get("/index/time1", response_class=PlainTextResponse)
async def get_time1():
    return datetime.datetime.now().strftime("%H:%M:%S")


@app.get("/index/time2", response_class=PlainTextResponse)
async def get_time2():
    return datetime.datetime.now().strftime("%H.%M.%S")


@app.get("/index/table_simple", response_class=JSONResponse)
async def get_data_simple():
    return redis_usr.redis_get_data_simple()


@app.get("/index/table_detail", response_class=JSONResponse)
async def get_data_detail():
    return redis_usr.redis_get_data_detail()


@app.post("/index/video_feed", response_class=JSONResponse)
async def get_video():
    return redis_usr.get_buf_video()


@app.get("/images_gt/{gt_name}/{filename}")
async def get_gt_data(gt_name: str, filename: str):
    return FileResponse(f"../data/target/faces-17" + f"/" + gt_name + f"/" + filename)


@app.get("/images_det/{d_time}/{filename}")
async def get_det_data(d_time: str, filename: str):
    return FileResponse(f"../data/output/faces-17" + f"/" + d_time + f"/" + filename)